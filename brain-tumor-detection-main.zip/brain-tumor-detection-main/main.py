from app import TumorDetectorGUI


if __name__ == "__main__":
    
    tumor_detector = TumorDetectorGUI()
    tumor_detector.window()